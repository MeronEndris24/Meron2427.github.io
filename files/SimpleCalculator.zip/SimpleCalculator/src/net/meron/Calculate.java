package net.meron;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Calculate extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        
        if(request.getParameter("a1").length() > 0) {
            int a1 = Integer.parseInt(request.getParameter("a1"));
            int b1 = Integer.parseInt(request.getParameter("b1"));
            out.println(a1 + " + " + b1 + " = " + (a1+b1));
        }
        
        if(request.getParameter("a2").length() > 0) {
            int a2 = Integer.parseInt(request.getParameter("a2"));
            int b2 = Integer.parseInt(request.getParameter("b2"));
            out.println(a2 + " * " + b2 + " = " + (a2*b2));
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
